package com.example.company.response;

import lombok.Data;

@Data
public class RoleResponse {
	private Long RoleId;
	private String userRole;
}
