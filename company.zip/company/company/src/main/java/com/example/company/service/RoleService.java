package com.example.company.service;

public class RoleService {

}
