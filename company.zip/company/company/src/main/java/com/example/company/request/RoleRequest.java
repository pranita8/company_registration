package com.example.company.request;

import lombok.Getter;

@Getter
public class RoleRequest {
	private Long RoleId;
	private String userRole;
}
